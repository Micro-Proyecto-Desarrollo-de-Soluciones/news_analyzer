"""
modelo-sesgo
============

Clasificador de orientacion politica de articulos de prensa, empaquetado para
ser consumido por la API de inferencias.

Interfaz publica:

    from modelo_sesgo.predict import predecir

    resultado = predecir(texto="...")
    # {"clase": "left", "probabilidades": {...}, "version": "0.1.0", ...}

El paquete es autocontenido: lleva el desmarcado del medio publicador, la
limpieza de texto, el vectorizador ajustado y el clasificador entrenado. Quien
lo usa no necesita conocer esa cadena ni replicarla, que es justamente lo que
evita que el modelo vea en produccion un texto distinto al que aprendio.
"""

import logging

from modelo_sesgo.config.core import PACKAGE_ROOT, config

# Logger del paquete con NullHandler, para no imponer configuracion de logging
# a la aplicacion que lo consuma.
# https://docs.python.org/3/howto/logging.html#configuring-logging-for-a-library
logging.getLogger(config.app.package_name).addHandler(logging.NullHandler())

with open(PACKAGE_ROOT / "VERSION", encoding="utf-8") as version_file:
    __version__ = version_file.read().strip()
