"""
Cadena de inferencia.

    texto crudo -> desmarcado -> limpieza -> vectorizador -> clasificador

Las cuatro etapas se aplican siempre en ese orden y son las mismas que se
usaron al entrenar. Ese es el unico proposito del paquete: garantizar que el
modelo vea en produccion exactamente el mismo tipo de texto que aprendio.

Los artefactos (vectorizador y clasificador ajustados, lista de medios) se
cargan una sola vez al importar el modulo, no en cada prediccion.
"""

from __future__ import annotations

from functools import lru_cache
from typing import Dict, List

import joblib
import numpy as np

from modelo_sesgo.config.core import TRAINED_MODEL_DIR, config
from modelo_sesgo.processing import desmarcado, limpieza


class ModeloNoEntrenado(RuntimeError):
    """Se levanta si el artefacto del modelo no esta en el paquete."""


@lru_cache(maxsize=1)
def cargar_artefactos() -> Dict:
    """Carga vectorizador, clasificador y lista de medios.

    Se cachea porque cargar el vectorizador implica reconstruir un vocabulario
    de veinte mil terminos, y hacerlo en cada peticion seria absurdo.
    """
    ruta_modelo = TRAINED_MODEL_DIR / config.app.archivo_modelo
    if not ruta_modelo.exists():
        raise ModeloNoEntrenado(
            f"No se encontro el artefacto del modelo en {ruta_modelo}. "
            "Corre modelo_sesgo/train_pipeline.py o copia el joblib entrenado."
        )

    paquete = joblib.load(ruta_modelo)
    nombres, meta_medios = desmarcado.cargar_nombres()

    version_artefacto = meta_medios.get("version_desmarcado")
    if version_artefacto != config.modelo.version_desmarcado:
        # No se interrumpe: el modelo sigue sirviendo. Pero se avisa, porque un
        # desfase aca significa que el texto que ve el modelo en inferencia
        # puede no coincidir con el del entrenamiento.
        import warnings

        warnings.warn(
            f"La lista de medios fue generada con la version {version_artefacto} "
            f"del desmarcado, pero el paquete declara {config.modelo.version_desmarcado}. "
            "Regenerar el artefacto o alinear las versiones.",
            RuntimeWarning,
        )

    return {
        "vectorizador": paquete["vectorizador"],
        "clasificador": paquete["clasificador"],
        "clases": list(paquete.get("clases", config.modelo.clases)),
        "patron_medios": desmarcado.compilar_patron(nombres),
    }


def preparar(texto: str) -> str:
    """Aplica desmarcado y limpieza. Devuelve el texto listo para vectorizar."""
    artefactos = cargar_artefactos()
    sin_medio = desmarcado.desmarcar_texto(texto, artefactos["patron_medios"])
    return limpieza.limpiar_texto(sin_medio)


def clasificar(texto: str) -> Dict:
    """Ejecuta la cadena completa sobre un texto crudo.

    Devuelve la clase predicha, las probabilidades por clase y el texto ya
    procesado, que `explain` necesita para identificar los terminos presentes.
    """
    artefactos = cargar_artefactos()
    texto_limpio = preparar(texto)

    X = artefactos["vectorizador"].transform([texto_limpio])
    probabilidades = artefactos["clasificador"].predict_proba(X)[0]
    clases: List[str] = artefactos["clases"]

    indice = int(np.argmax(probabilidades))

    return {
        "clase": clases[indice],
        "probabilidades": {
            clase: float(valor) for clase, valor in zip(clases, probabilidades)
        },
        "texto_procesado": texto_limpio,
        "matriz": X,
    }
