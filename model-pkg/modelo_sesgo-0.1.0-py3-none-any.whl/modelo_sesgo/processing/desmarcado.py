"""
Desmarcado del medio publicador, camino de inferencia.

Por que existe este paso
------------------------
La etiqueta del dataset esta asociada al medio y no al articulo: de 491 medios,
484 tienen una unica orientacion. Por eso cualquier rastro del publicador
dentro del texto le entrega la clase al modelo sin que aprenda nada de
orientacion politica. La medicion lo confirmo: Washington Times se nombra en el
99.1% de sus articulos frente al 0.6% de los ajenos.

Relacion con el repositorio de entrenamiento
--------------------------------------------
Este modulo es la contraparte de inferencia de src/desmarcado.py. Contiene solo
lo necesario para limpiar UN texto: no incluye la derivacion de la lista de
medios (que requiere la columna `source`, inexistente en produccion) ni la
version vectorizada sobre pandas. Gracias a eso el paquete no depende de pandas.

IMPORTANTE: las reglas de abajo deben permanecer identicas a las de
src/desmarcado.py. Si divergen, el modelo vera en produccion un texto distinto
al que aprendio. El campo `version_desmarcado` de config.yml existe para
detectar ese desfase, y tests/test_prediction.py lo verifica.
"""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import List, Optional, Tuple

from modelo_sesgo.config.core import TRAINED_MODEL_DIR, config

REEMPLAZO = config.modelo.reemplazo_desmarcado

# --- Boilerplate y patrones estructurales -----------------------------------
# Cada entrada es (disparador, patron, reemplazo). El disparador es una
# subcadena literal barata: el regex solo se aplica si el texto la contiene.
# Sin ese filtro previo, patrones como `[^.\n]*...[^.\n]*` se evaluan en cada
# posicion del texto y dominan el tiempo total, aunque la mayoria de los
# articulos ni siquiera contenga la frase. `None` = aplicar siempre.
PATRONES_ESTRUCTURALES: List[Tuple[Optional[str], re.Pattern, str]] = [
    # Dateline de agencia al inicio: "WASHINGTON (Reuters) - ..."
    (None, re.compile(r"^\s*[A-Z][A-Za-z\.\s]{1,30},?\s*\([^)]{2,30}\)\s*[-–—]\s*"), ""),
    # Linea de atribucion: "Fox News' Bill Mears contributed to this report."
    (
        "contributed to this report",
        re.compile(r"[^.\n]*contributed to this report[^.\n]*\.?", re.I),
        "",
    ),
    # Copyright y permisos de reimpresion
    ("©", re.compile(r"©[^\n]*"), ""),
    ("reprint permission", re.compile(r"[Cc]lick here for reprint permission\.?"), ""),
    # Boilerplate de suscripcion
    ("newsletter", re.compile(r"sign up for[^\n\.]{0,80}newsletter\.?", re.I), ""),
    ("newsletter", re.compile(r"subscribe to[^\n\.]{0,80}newsletter\.?", re.I), ""),
    # Encabezado de resumen tipico de CNN
    ("Story highlights", re.compile(r"^\s*Story highlights\s*", re.I), ""),
    # Links internos convertidos a texto
    ("ead more at", re.compile(r"[Rr]ead more at[^\n\.]{0,60}\.?"), ""),
    # URLs sueltas
    ("http", re.compile(r"https?://\S+"), ""),
]

# Dominios sueltos escritos en el cuerpo ("cnn.com", "www.foxnews.com").
PATRON_DOMINIO = re.compile(
    r"\b(?:www\.)?[a-z0-9][a-z0-9\-]{1,40}\.(?:com|org|net|gov|edu|io|us|co\.uk)\b",
    re.I,
)

PATRON_ESPACIOS = re.compile(r"\s+")


def cargar_nombres(ruta: Optional[Path] = None) -> Tuple[List[str], dict]:
    """Lee la lista de medios que viaja como artefacto dentro del paquete."""
    ruta = ruta or TRAINED_MODEL_DIR / config.app.archivo_medios
    datos = json.loads(Path(ruta).read_text(encoding="utf-8"))
    return datos["nombres"], datos


def compilar_patron(nombres: List[str]) -> Optional[re.Pattern]:
    """Compila el patron de nombres de medio.

    Sin re.IGNORECASE a proposito: los nombres aparecen capitalizados en el
    texto, asi que el matcheo sensible a mayusculas es casi igual de efectivo,
    mas rapido, y ademas protege a los nombres compuestos ambiguos ("The Hill"
    no captura "climbing the hill").

    Se agregan explicitamente las variantes en mayusculas, que son estilo de
    casa de varios medios ("POLITICO reported"). Sin ellas Politico quedaba en
    0.642 de auto-mencion pese a estar en la lista.
    """
    if not nombres:
        return None

    variantes = set()
    for nombre in nombres:
        variantes.add(nombre)
        variantes.add(nombre.upper())

    ordenadas = sorted(variantes, key=len, reverse=True)
    alternativas = "|".join(re.escape(nombre) for nombre in ordenadas)
    return re.compile(rf"\b(?:{alternativas})\b")


def desmarcar_texto(texto: str, patron: Optional[re.Pattern]) -> str:
    """Elimina del texto las huellas que identifican al medio publicador."""
    if not texto:
        return ""

    if patron is not None:
        texto = patron.sub(REEMPLAZO, texto)

    texto = PATRON_DOMINIO.sub(REEMPLAZO, texto)

    for disparador, patron_est, reemplazo in PATRONES_ESTRUCTURALES:
        if disparador is not None and disparador.lower() not in texto.lower():
            continue
        texto = patron_est.sub(reemplazo, texto)

    return PATRON_ESPACIOS.sub(" ", texto).strip()
