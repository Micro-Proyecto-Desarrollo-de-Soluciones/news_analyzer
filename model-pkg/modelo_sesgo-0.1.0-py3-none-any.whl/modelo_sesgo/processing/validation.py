"""
Validacion de la entrada de inferencia.

El esquema replica el contrato acordado con el tablero: un texto crudo y un
titulo opcional. El paquete recibe el articulo SIN limpiar; toda la
transformacion ocurre adentro, para que sea identica a la del entrenamiento.
"""

from typing import List, Optional, Tuple

from pydantic import BaseModel, Field, ValidationError

from modelo_sesgo.config.core import config


class EntradaArticulo(BaseModel):
    """Un articulo a clasificar."""

    texto: str = Field(min_length=1, description="Cuerpo del articulo, en crudo.")
    titulo: Optional[str] = Field(default=None, description="Titulo del articulo.")


class MultiplesEntradas(BaseModel):
    """Lote de articulos."""

    entradas: List[EntradaArticulo]


def validar_entrada(*, texto: str, titulo: Optional[str] = None) -> Tuple[Optional[EntradaArticulo], Optional[dict]]:
    """Valida un articulo y devuelve (entrada, errores).

    Un texto vacio es un error y no se clasifica. Un texto corto no lo es: en
    entrenamiento los articulos de menos de MIN_PALABRAS se descartaron, pero en
    inferencia rechazar la peticion seria peor que responder advirtiendo que la
    prediccion es poco confiable. Esa advertencia se resuelve en predict.py.
    """
    try:
        entrada = EntradaArticulo(texto=texto, titulo=titulo)
    except ValidationError as error:
        return None, error.json()

    return entrada, None


def es_texto_corto(texto: str) -> bool:
    """True si el texto queda por debajo del umbral usado al entrenar."""
    return len(texto.split()) < config.modelo.min_palabras
