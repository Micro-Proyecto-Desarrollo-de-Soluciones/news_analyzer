"""
Limpieza clasica de NLP, especifica del enfoque TF-IDF.

Contraparte de inferencia de src/tfidf/representacion.py. Se aplica DESPUES del
desmarcado y ANTES de vectorizar: minusculas, se quitan puntuacion y digitos, se
descartan stopwords y se lematiza con WordNet.

Esta limpieza mejora TF-IDF porque reduce el vocabulario a palabras con
contenido, pero degradaria a un modelo de embeddings, que esta entrenado sobre
texto natural. Por eso vive aca y no en el desmarcado, que es comun a ambos
enfoques.

IMPORTANTE: debe permanecer identica a la de src/tfidf/representacion.py. El
vectorizador del artefacto fue ajustado sobre texto limpiado con esas reglas; si
divergen, el vocabulario aprendido deja de corresponderse con lo que llega en
inferencia.
"""

from __future__ import annotations

import re
from typing import List

from modelo_sesgo.config.core import config

# El desmarcado reemplaza las menciones al publicador por un marcador. Sin
# quitarlo aparte, la limpieza de puntuacion lo reduce a la palabra suelta
# "medio", que termina apareciendo en casi todos los articulos y se cuela entre
# los terminos de mayor peso sin ser contenido real. Es la misma familia de fuga
# que motivo el desmarcado, asi que se elimina explicitamente.
PATRON_MARCADOR = re.compile(re.escape(config.modelo.reemplazo_desmarcado.lower()))

# Se quitan numeros ademas de puntuacion: fechas y cifras sueltas no aportan a
# distinguir orientacion politica y solo inflan el vocabulario.
PATRON_NO_ALFABETICO = re.compile(r"[^a-zA-Z\s]")
PATRON_ESPACIOS = re.compile(r"\s+")


# =============================================================================
# RECURSOS DE NLTK
# =============================================================================

_STOPWORDS = None
_LEMATIZADOR = None


def _descargar_recursos_nltk() -> None:
    """Descarga los recursos de NLTK que hacen falta, si no estan ya.

    Se hace de forma perezosa para no demorar el import del paquete. En un
    contenedor conviene ejecutarlo al construir la imagen y no al atender la
    primera peticion, que de lo contrario requiere salida a internet.
    """
    import nltk

    recursos = {
        "corpora/stopwords": "stopwords",
        "corpora/wordnet": "wordnet",
        "corpora/omw-1.4": "omw-1.4",
    }
    for ruta, paquete in recursos.items():
        try:
            nltk.data.find(ruta)
        except LookupError:
            nltk.download(paquete, quiet=True)


def _stopwords() -> frozenset:
    """Carga una sola vez el set de stopwords."""
    global _STOPWORDS
    if _STOPWORDS is None:
        _descargar_recursos_nltk()
        from nltk.corpus import stopwords

        _STOPWORDS = frozenset(stopwords.words(config.modelo.idioma_stopwords))
    return _STOPWORDS


def _lematizador():
    """Instancia una sola vez el lematizador WordNet."""
    global _LEMATIZADOR
    if _LEMATIZADOR is None:
        _descargar_recursos_nltk()
        from nltk.stem import WordNetLemmatizer

        _LEMATIZADOR = WordNetLemmatizer()
    return _LEMATIZADOR


# =============================================================================
# LIMPIEZA
# =============================================================================


def normalizar(texto: str) -> str:
    """Minusculas, y quita el marcador de desmarcado, puntuacion y digitos."""
    if not isinstance(texto, str):
        return ""
    texto = texto.lower()
    texto = PATRON_MARCADOR.sub(" ", texto)
    texto = PATRON_NO_ALFABETICO.sub(" ", texto)
    return PATRON_ESPACIOS.sub(" ", texto).strip()


def tokenizar(texto_normalizado: str) -> List[str]:
    """Separa el texto ya normalizado en tokens."""
    if not texto_normalizado:
        return []
    return texto_normalizado.split(" ")


def quitar_stopwords(tokens: List[str]) -> List[str]:
    """Descarta palabras funcionales y tokens de un solo caracter."""
    stop = _stopwords()
    return [t for t in tokens if t not in stop and len(t) > 1]


def lematizar(tokens: List[str]) -> List[str]:
    """Reduce cada palabra a su lema (running/ran/runs -> run)."""
    lema = _lematizador()
    return [lema.lemmatize(t) for t in tokens]


def limpiar_texto(texto: str) -> str:
    """Pipeline completo: normalizar, tokenizar, stopwords, lematizar.

    Devuelve un string con los tokens separados por espacio, que es lo que
    TfidfVectorizer espera por defecto.
    """
    tokens = tokenizar(normalizar(texto))
    tokens = quitar_stopwords(tokens)
    tokens = lematizar(tokens)
    return " ".join(tokens)
