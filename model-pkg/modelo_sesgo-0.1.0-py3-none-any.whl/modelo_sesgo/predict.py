"""
Interfaz publica del paquete.

Es lo unico que necesita conocer quien lo consuma:

    from modelo_sesgo.predict import predecir

    resultado = predecir(texto="...")

Todo lo demas (desmarcado, limpieza, vectorizacion, clasificador) ocurre
adentro. El consumidor entrega el articulo en crudo y no debe preprocesar nada:
si lo hiciera, el texto llegaria al modelo distinto de como fue entrenado.
"""

from __future__ import annotations

from typing import Dict, List, Optional

from modelo_sesgo import __version__
from modelo_sesgo.config.core import config
from modelo_sesgo.explain import explicar
from modelo_sesgo.pipeline import clasificar
from modelo_sesgo.processing.validation import es_texto_corto, validar_entrada


def predecir(
    *,
    texto: str,
    titulo: Optional[str] = None,
    con_explicacion: bool = False,
) -> Dict:
    """Clasifica la orientacion politica de un articulo.

    Parametros
    ----------
    texto : str
        Cuerpo del articulo, en crudo y sin limpiar.
    titulo : str, opcional
        Se acepta por compatibilidad con el contrato del tablero. Hoy no se usa
        en la prediccion: el equipo no decidio si concatenarlo al cuerpo, y el
        modelo fue entrenado solo sobre el cuerpo.
    con_explicacion : bool
        Si es True, agrega los terminos que mas empujaron hacia la clase
        predicha.

    Devuelve
    --------
    dict con las claves:
        clase            : "center" | "left" | "right"
        probabilidades   : dict con las tres clases, suman 1
        version          : version del paquete que produjo la prediccion
        advertencias     : lista de avisos, vacia si no hay
        errores          : None si la entrada era valida
        explicacion      : presente solo si con_explicacion=True
    """
    entrada, errores = validar_entrada(texto=texto, titulo=titulo)

    if errores is not None:
        return {
            "clase": None,
            "probabilidades": None,
            "version": __version__,
            "advertencias": [],
            "errores": errores,
        }

    advertencias: List[str] = []
    if es_texto_corto(entrada.texto):
        # No se rechaza la peticion. En entrenamiento los articulos por debajo
        # del umbral se descartaron, asi que el modelo no vio textos asi, pero
        # negarse a responder seria peor para el usuario que responder avisando.
        advertencias.append(
            f"El texto tiene menos de {config.modelo.min_palabras} palabras. "
            "La prediccion puede ser poco confiable."
        )

    resultado = clasificar(entrada.texto)

    respuesta = {
        "clase": resultado["clase"],
        "probabilidades": resultado["probabilidades"],
        "version": __version__,
        "advertencias": advertencias,
        "errores": None,
    }

    if con_explicacion:
        respuesta["explicacion"] = explicar(resultado["matriz"], resultado["clase"])

    return respuesta


def predecir_lote(articulos: List[Dict], con_explicacion: bool = False) -> List[Dict]:
    """Clasifica varios articulos. Cada elemento es {"texto": ..., "titulo": ...}."""
    return [
        predecir(
            texto=articulo.get("texto", ""),
            titulo=articulo.get("titulo"),
            con_explicacion=con_explicacion,
        )
        for articulo in articulos
    ]
