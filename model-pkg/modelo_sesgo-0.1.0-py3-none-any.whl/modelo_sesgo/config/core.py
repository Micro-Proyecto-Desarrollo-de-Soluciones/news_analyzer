"""
Carga y validacion de la configuracion del paquete.

Sigue el patron del taller 5: el YAML se lee con strictyaml y se valida contra
modelos de pydantic, de modo que un campo faltante o mal escrito falla al
importar el paquete y no en medio de una prediccion.

Nota sobre pydantic 2: la plantilla original nombraba el atributo
`model_config`, que en pydantic 2 esta reservado para la configuracion interna
del modelo. Aca se usa `modelo` para evitar la colision.
"""

from pathlib import Path
from typing import List, Optional

from pydantic import BaseModel
from strictyaml import YAML, load

import modelo_sesgo

# --- Directorios del paquete ------------------------------------------------
PACKAGE_ROOT = Path(modelo_sesgo.__file__).resolve().parent
ROOT = PACKAGE_ROOT.parent
CONFIG_FILE_PATH = PACKAGE_ROOT / "config.yml"
TRAINED_MODEL_DIR = PACKAGE_ROOT / "trained"


class AppConfig(BaseModel):
    """Configuracion a nivel de aplicacion."""

    package_name: str
    archivo_modelo: str
    archivo_medios: str


class ModeloConfig(BaseModel):
    """Configuracion de la cadena de inferencia."""

    representacion: str
    clases: List[str]

    # Desmarcado del medio publicador
    version_desmarcado: str
    reemplazo_desmarcado: str
    min_articulos_medio: int

    # Limpieza clasica
    idioma_stopwords: str

    # Validacion y explicacion
    min_palabras: int
    n_terminos_explicacion: int


class Config(BaseModel):
    """Configuracion completa."""

    app: AppConfig
    modelo: ModeloConfig


def find_config_file() -> Path:
    """Ubica el archivo de configuracion dentro del paquete."""
    if CONFIG_FILE_PATH.is_file():
        return CONFIG_FILE_PATH
    raise FileNotFoundError(f"No se encontro la configuracion en {CONFIG_FILE_PATH!r}")


def fetch_config_from_yaml(cfg_path: Optional[Path] = None) -> YAML:
    """Lee el YAML con la configuracion del paquete."""
    cfg_path = cfg_path or find_config_file()
    with open(cfg_path, "r", encoding="utf-8") as conf_file:
        return load(conf_file.read())


def create_and_validate_config(parsed_config: Optional[YAML] = None) -> Config:
    """Valida los valores de la configuracion contra los esquemas de arriba."""
    if parsed_config is None:
        parsed_config = fetch_config_from_yaml()

    datos = parsed_config.data
    return Config(
        app=AppConfig(**datos),
        modelo=ModeloConfig(**datos),
    )


config = create_and_validate_config()
