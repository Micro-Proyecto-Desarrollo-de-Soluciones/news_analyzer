"""
Explicacion de una prediccion.

Para cada articulo devuelve los terminos que mas empujaron hacia la clase
predicha, combinando el peso TF-IDF del termino en ese texto con el coeficiente
que la regresion logistica le asigna a esa clase.

Por que esto es posible con TF-IDF y no con embeddings
------------------------------------------------------
En TF-IDF cada columna de la matriz ES una palabra o un bigrama, asi que el
coeficiente del clasificador para esa columna se lee directamente como "cuanto
empuja este termino hacia esta clase". En un modelo de embeddings las 768
dimensiones no corresponden a palabras y no hay nada equivalente que mostrar
sin recurrir a metodos de atribucion mucho mas costosos.

Fue una de las razones para empaquetar el enfoque disperso pese a su menor F1.
"""

from __future__ import annotations

from typing import Dict, List

import numpy as np

from modelo_sesgo.config.core import config
from modelo_sesgo.pipeline import cargar_artefactos


def explicar(matriz, clase: str, n_terminos: int = None) -> List[Dict]:
    """Terminos que mas contribuyeron a la clase predicha.

    `matriz` es la fila TF-IDF del articulo, tal como la devuelve
    `pipeline.clasificar`. Solo se consideran los terminos efectivamente
    presentes en el texto: un coeficiente alto no explica nada si la palabra no
    aparece en el articulo.

    La contribucion es el producto del peso TF-IDF por el coeficiente de la
    clase. Se devuelven solo las contribuciones positivas, que son las que
    empujaron hacia la clase predicha; las negativas empujaban en contra.
    """
    n_terminos = n_terminos or config.modelo.n_terminos_explicacion
    artefactos = cargar_artefactos()

    clasificador = artefactos["clasificador"]
    vectorizador = artefactos["vectorizador"]
    clases = artefactos["clases"]

    if clase not in clases:
        return []

    indice_clase = clases.index(clase)
    coeficientes = clasificador.coef_[indice_clase]
    terminos = vectorizador.get_feature_names_out()

    fila = matriz.tocoo()
    contribuciones = [
        (terminos[col], float(valor * coeficientes[col]))
        for col, valor in zip(fila.col, fila.data)
    ]

    positivas = [(t, c) for t, c in contribuciones if c > 0]
    positivas.sort(key=lambda par: par[1], reverse=True)
    top = positivas[:n_terminos]

    if not top:
        return []

    # Se normaliza para que los pesos devueltos sumen 1 y sean comparables
    # entre articulos, independientemente de la escala de los coeficientes.
    total = sum(peso for _, peso in top)
    return [
        {"text": termino, "weight": round(peso / total, 4)}
        for termino, peso in top
    ]
